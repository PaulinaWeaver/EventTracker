package com.example.a360projectpaulinaweaver;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

// This helper class contains all the logic for working with SMS in the app.
// It handles permission checks, sending SMS, and storing the user’s phone number.
public class SmsHelper {

    // A constant number used when asking the user for SMS permission
    public static final int REQ_SEND_SMS = 9001;

    // Keys for storing phone number in SharedPreferences
    private static final String PREFS = "prefs";
    private static final String KEY_PHONE = "sms_phone";

    // Check if the app currently has SMS permission
    public static boolean hasSmsPermission(Context ctx) {
        return ContextCompat.checkSelfPermission(ctx, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    // Ask the user to grant SMS permission
    public static void requestSmsPermission(Activity activity) {
        ActivityCompat.requestPermissions(activity,
                new String[]{Manifest.permission.SEND_SMS}, REQ_SEND_SMS);
    }

    // Actually send an SMS to a given phone number with the given text message
    public static void sendSms(String phone, String body) {
        SmsManager sms = SmsManager.getDefault();  // Built-in Android SMS manager
        sms.sendTextMessage(phone, null, body, null, null);
    }

    // Save the phone number the user entered into local storage
    public static void savePhone(Context ctx, String phone) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY_PHONE, phone).apply();
    }

    // Retrieve the saved phone number from local storage
    public static String getPhone(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_PHONE, "");
    }
}

