package com.example.a360projectpaulinaweaver;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.ViewHolder> {

    // Variables
    private final Context context;
    private Cursor cursor;
    private final EventTrackerDB db;

    // Constructor
    public EventAdapter(Context context, Cursor cursor, EventTrackerDB db) {
        this.context = context;
        this.cursor = cursor;
        this.db = db;
    }

    // Create each row layout
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.event_item, parent, false);
        return new ViewHolder(view);
    }

    // Fill each row with event data
    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        if (!cursor.moveToPosition(position)) return;

        // Get values from database
        int id = cursor.getInt(cursor.getColumnIndexOrThrow(EventTrackerDB.COL_EVENT_ID));
        String n = cursor.getString(cursor.getColumnIndexOrThrow(EventTrackerDB.COL_EVENT_NAME));
        String d = cursor.getString(cursor.getColumnIndexOrThrow(EventTrackerDB.COL_EVENT_DATE));
        String t = cursor.getString(cursor.getColumnIndexOrThrow(EventTrackerDB.COL_EVENT_TIME));
        String desc = cursor.getString(cursor.getColumnIndexOrThrow(EventTrackerDB.COL_EVENT_DESC));

        // Show event name and date/time
        h.textViewEventName.setText(n);
        h.textViewEventDate.setText(d + " " + t);

        // If the user taps the row, open EventDetailsActivity
        h.itemView.setOnClickListener(v -> {
            Intent i = new Intent(context, EventDetailsActivity.class);
            i.putExtra("id", id);
            i.putExtra("name", n);
            i.putExtra("desc", desc);
            i.putExtra("date", d);
            i.putExtra("time", t);
            context.startActivity(i);
        });

        // If delete button clicked, remove from DB and refresh list
        h.buttonDelete.setOnClickListener(v -> {
            db.deleteEvent(id);

            // Get updated data
            Cursor newCursor = db.getAllEvents();
            if (cursor != null) cursor.close();
            cursor = newCursor;

            // Remove this row from RecyclerView
            int adapterPos = h.getAdapterPosition();
            if (adapterPos != RecyclerView.NO_POSITION) {
                notifyItemRemoved(adapterPos);
            }
        });
    }

    // Tell RecyclerView how many rows exist
    @Override
    public int getItemCount() {
        return (cursor == null) ? 0 : cursor.getCount();
    }

    // ViewHolder keeps references to the row views
    static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView textViewEventName, textViewEventDate;
        final ImageButton buttonDelete;
        ViewHolder(View itemView) {
            super(itemView);
            textViewEventName = itemView.findViewById(R.id.textViewEventName);
            textViewEventDate = itemView.findViewById(R.id.textViewEventDate);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }
}


