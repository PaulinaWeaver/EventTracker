package com.example.a360projectpaulinaweaver.login;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.a360projectpaulinaweaver.EventTrackerDB;
import com.example.a360projectpaulinaweaver.MainActivity;
import com.example.a360projectpaulinaweaver.R;

public class LoginActivity extends AppCompatActivity {

    // UI references
    private EditText editUsername;
    private EditText editPassword;

    // Database helper
    private EventTrackerDB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Make the DB helper to check/add users
        db = new EventTrackerDB(this);

        // Get references to the views on the screen
        editUsername = findViewById(R.id.editTextText);
        editPassword = findViewById(R.id.editTextTextPassword);
        Button btnLogin = findViewById(R.id.loginButton);
        Button btnRegister = findViewById(R.id.createAccountButton);

        // When buttons are tapped, run these methods
        btnLogin.setOnClickListener(v -> login());
        btnRegister.setOnClickListener(v -> register());
    }

    // Try to log in with the username and password
    private void login() {
        String u = editUsername.getText().toString().trim();
        String p = editPassword.getText().toString().trim();
        // Ask DB if this user exists with this password
        if (db.checkUser(u, p)) {
            // If OK, go to the main screen and close login
            startActivity(new Intent(this, MainActivity.class));
            finish();
        } else {
            // If not found, show a quick message
            Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
        }
    }

    // Create a new account with the username and password provided
    private void register() {
        String u = editUsername.getText().toString().trim();
        String p = editPassword.getText().toString().trim();

        // Ask DB to add the user
        if (db.addUser(u, p)) {
            Toast.makeText(this, "Account created! Please login.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
        }
    }
}