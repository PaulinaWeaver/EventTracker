package com.example.a360projectpaulinaweaver;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AddEventActivity extends AppCompatActivity {

    // Views on the screen
    private EditText editTextEventName;
    private EditText editTextEventDescription;
    private TextView tvSelectedDateTime;

    // What the user picked
    private String selectedDate = "";
    private String selectedTime = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        // Set up toolbar with a back arrow and title
        MaterialToolbar toolbar = findViewById(R.id.topAppBar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true); // show back arrow
            getSupportActionBar().setTitle(R.string.add_event);    // set screen title
        }
        toolbar.setNavigationOnClickListener(v -> finish()); // go back without saving

        // Grab references to all the views
        editTextEventName = findViewById(R.id.editTextEventName);
        editTextEventDescription = findViewById(R.id.editTextEventDescription);
        Button buttonSelectDate = findViewById(R.id.buttonSelectDate);
        Button buttonSelectTime = findViewById(R.id.buttonSelectTime);
        Button buttonSaveEvent = findViewById(R.id.buttonSaveEvent);
        tvSelectedDateTime = findViewById(R.id.tvSelectedDateTime);

        // Hook up button clicks
        buttonSelectDate.setOnClickListener(v -> showDatePicker());
        buttonSelectTime.setOnClickListener(v -> showTimePicker());
        buttonSaveEvent.setOnClickListener(v -> saveEvent());
    }

    // Show the calendar to pick a date
    private void showDatePicker() {
        Calendar c = Calendar.getInstance();
        new DatePickerDialog(
                this,
                (view, y, m, d) -> {
                    // month is 0-based, so add 1
                    selectedDate = String.format(Locale.US, "%02d/%02d/%04d", (m + 1), d, y);
                    // update preview label
                    tvSelectedDateTime.setText(selectedDate + (selectedTime.isEmpty() ? "" : " " + selectedTime));
                },
                c.get(Calendar.YEAR),
                c.get(Calendar.MONTH),
                c.get(Calendar.DAY_OF_MONTH)
        ).show();
    }

    // Show the clock to pick a time (12-hour with AM/PM)
    private void showTimePicker() {
        Calendar c = Calendar.getInstance();
        new TimePickerDialog(
                this,
                (view, hourOfDay, minute) -> {
                    String amPm = (hourOfDay >= 12) ? "PM" : "AM";
                    int hour12  = hourOfDay % 12;
                    if (hour12 == 0) hour12 = 12; // 0 -> 12
                    selectedTime = String.format(Locale.US, "%02d:%02d %s", hour12, minute, amPm);
                    // update preview label
                    tvSelectedDateTime.setText((selectedDate.isEmpty() ? "" : selectedDate + " ") + selectedTime);
                },
                c.get(Calendar.HOUR_OF_DAY),
                c.get(Calendar.MINUTE),
                false // use 12-hour mode
        ).show();
    }

    // Save the event into the database and schedule the reminder
    private void saveEvent() {
        String name = editTextEventName.getText().toString().trim();
        String desc = editTextEventDescription.getText().toString().trim();

        // Quick validation: all fields must be filled
        if (name.isEmpty() || selectedDate.isEmpty() || selectedTime.isEmpty()) {
            tvSelectedDateTime.setText("Please fill all fields and select date/time");
            return;
        }

        // Insert the event in the DB
        EventTrackerDB db = new EventTrackerDB(this);
        long rowId = db.addEvent(name, desc, selectedDate, selectedTime);

        if (rowId != -1) {
            // Only schedule if the insert worked
            scheduleSmsReminder((int) rowId, name, selectedDate, selectedTime);
            Toast.makeText(this, "Event added", Toast.LENGTH_SHORT).show();
            finish(); // go back to the list
        } else {
            // Show user if it failed
            Toast.makeText(this, "Failed to add event", Toast.LENGTH_SHORT).show();
        }
    }

    // Set an alarm to fire at the event time. The broadcast goes to ReminderReceiver.
    private void scheduleSmsReminder(int requestCode, String name, String date, String time) {
        long triggerAt = parseToMillis(date, time); // convert date and time to milliseconds
        if (triggerAt <= System.currentTimeMillis()) {
            // Don't schedule if time already passed
            return;
        }

        AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);

        Intent intent = new Intent(this, ReminderReceiver.class);
        intent.putExtra("event_name", name);
        intent.putExtra("event_date", date);
        intent.putExtra("event_time", time);

        int flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;

        PendingIntent pi = PendingIntent.getBroadcast(this, requestCode, intent, flags);

        if (am != null) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        }
    }

    // Turn the date/time strings into a millisecond timestamp
    private long parseToMillis(String date, String time) {
        try {
            SimpleDateFormat fmt = new SimpleDateFormat("MM/dd/yyyy hh:mm a", Locale.US);
            Date d = fmt.parse(date + " " + time);
            return (d != null) ? d.getTime() : 0L;
        } catch (Exception e) {
            return 0L; // if parsing fails, return 0 to skip scheduling
        }
    }
}