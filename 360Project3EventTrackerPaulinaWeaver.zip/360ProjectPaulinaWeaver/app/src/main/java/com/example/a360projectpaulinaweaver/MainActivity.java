package com.example.a360projectpaulinaweaver;

import android.graphics.Color;
import android.os.Bundle;
import android.content.Intent;
import android.database.Cursor;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.appbar.MaterialToolbar;

public class MainActivity extends AppCompatActivity {

    // Declare variables for database and list view
    private EventTrackerDB db;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);  // Load main screen layout

        // Set up toolbar as the app bar
        MaterialToolbar toolbar = findViewById(R.id.topAppBar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            // Show "My Events" as the title
            getSupportActionBar().setTitle(R.string.my_events);
        }

        // Create database instance
        db = new EventTrackerDB(this);

        // Find RecyclerView in layout and make it a vertical list (1 column)
        recyclerView = findViewById(R.id.eventRecyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 1));

        // Load and display events from database
        loadEvents();

        // Floating button to add a new event
        FloatingActionButton fab = findViewById(R.id.fab_add_event);
        fab.setOnClickListener(v -> {
            // When clicked, open AddEventActivity
            startActivity(new Intent(MainActivity.this, AddEventActivity.class));
        });
    }

    // Query database and show events in RecyclerView
    private void loadEvents() {
        Cursor cursor = db.getAllEvents();  // Get all events
        EventAdapter adapter = new EventAdapter(this, cursor, db);  // Create adapter
        recyclerView.setAdapter(adapter);  // Attach adapter to RecyclerView
    }

    // Refresh the list when coming back from Add screen
    @Override
    protected void onResume() {
        super.onResume();
        loadEvents();  // Reload events every time the activity is resumed
    }

    // Show the toolbar menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        // Make overflow menu icon black
        MaterialToolbar toolbar = findViewById(R.id.topAppBar);
        if (toolbar.getOverflowIcon() != null) {
            toolbar.getOverflowIcon().setTint(Color.BLACK);
        }
        return true;
    }

    // Handle clicks on the toolbar menu items
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_sms) {
            // Open SMS permission/settings screen
            startActivity(new Intent(this, SmsPermissionActivity.class));
            return true;
        } else if (item.getItemId() == R.id.action_logout) {
            // Log out → go back to login screen
            startActivity(new Intent(this, com.example.a360projectpaulinaweaver.login.LoginActivity.class));
            finish(); // Close MainActivity so user can't come back with back button
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

