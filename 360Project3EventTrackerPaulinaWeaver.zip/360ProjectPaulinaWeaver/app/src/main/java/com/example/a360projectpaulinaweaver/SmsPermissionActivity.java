package com.example.a360projectpaulinaweaver;

import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.view.MenuItem;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.textfield.TextInputEditText;

import androidx.appcompat.app.AppCompatActivity;

public class SmsPermissionActivity extends AppCompatActivity {

    // UI elements
    private TextView tvStatus;
    private TextInputEditText etPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        //  Setup toolbar with a back arrow
        MaterialToolbar toolbar = findViewById(R.id.topAppBar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true); // show back arrow
            getSupportActionBar().setTitle(R.string.sms_permissions); // show correct title
        }

        // Link variables to the UI elements
        tvStatus = findViewById(R.id.tvPermissionStatus);
        Button btnRequest = findViewById(R.id.btnRequestPermission);
        Button btnSavePhone = findViewById(R.id.btnSavePhone);
        Button btnTestSms = findViewById(R.id.btnTestSms);
        etPhone = findViewById(R.id.etPhone);

        // Pre-fill the phone box with a previously saved number
        etPhone.setText(SmsHelper.getPhone(this));

        // Request SMS permission when user taps button
        btnRequest.setOnClickListener(v -> {
            if (!SmsHelper.hasSmsPermission(this)) {
                // Ask Android to show permission popup
                SmsHelper.requestSmsPermission(this);
            } else {
                Toast.makeText(this, "Permission already granted", Toast.LENGTH_SHORT).show();
            }
        });

        //  Save phone number to local storage
        btnSavePhone.setOnClickListener(v -> {
            String phone = String.valueOf(etPhone.getText()).trim();
            if (phone.isEmpty()) {
                Toast.makeText(this, "Enter a phone number", Toast.LENGTH_SHORT).show();
            } else {
                SmsHelper.savePhone(this, phone); // save locally
                Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
            }
        });

        //  Test sending a text message
        btnTestSms.setOnClickListener(v -> {
            String phone = SmsHelper.getPhone(this);
            if (phone.isEmpty()) {
                Toast.makeText(this, "Save your phone number first", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!SmsHelper.hasSmsPermission(this)) {
                Toast.makeText(this, "Grant SMS permission first", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                SmsHelper.sendSms(phone, "Test from Event Tracker");
                Toast.makeText(this, "Test SMS sent", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "SMS failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        // Update status text when screen opens
        updateStatus();
    }

    // Update text view to show if permission is granted or not
    private void updateStatus() {
        tvStatus.setText(SmsHelper.hasSmsPermission(this) ?
                "SMS Permission Granted" : "SMS Permission Denied");
    }

    // Handle result of permission popup (grant or deny)
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SmsHelper.REQ_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
            updateStatus(); // refresh text
        }
    }

    // Handle toolbar back button click
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish(); // closes SmsPermissionActivity and returns to MainActivity
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
