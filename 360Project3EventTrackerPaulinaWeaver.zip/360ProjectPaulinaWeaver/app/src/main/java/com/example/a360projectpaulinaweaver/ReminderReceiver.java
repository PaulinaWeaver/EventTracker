package com.example.a360projectpaulinaweaver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

// This class runs automatically when the AlarmManager triggers a reminder.
// It checks SMS permission and phone number, then sends a text reminder for the event.
public class ReminderReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // Get event details that were passed when scheduling the alarm
        String eventName = intent.getStringExtra("event_name");
        String eventDate = intent.getStringExtra("event_date");
        String eventTime = intent.getStringExtra("event_time");

        // Get saved phone number from helper
        String phone = SmsHelper.getPhone(context);

        // If no phone number is saved, do nothing
        if (phone.isEmpty()) {
            Log.w("ReminderReceiver", "No phone saved; skipping SMS");
            return;
        }

        // If permission was not granted, do nothing
        if (!SmsHelper.hasSmsPermission(context)) {
            Log.w("ReminderReceiver", "No SMS permission; skipping SMS");
            return;
        }

        // Build the reminder message text
        String msg = "Reminder: \"" + eventName + "\" is today (" + eventDate + " " + eventTime + ").";

        try {
            // Try to send the SMS using helper class
            SmsHelper.sendSms(phone, msg);
            Log.i("ReminderReceiver", "SMS sent: " + msg);
        } catch (Exception e) {
            // If sending failed, log the error
            Log.e("ReminderReceiver", "SMS failed", e);
        }
    }
}
