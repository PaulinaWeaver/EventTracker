package com.example.a360projectpaulinaweaver;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;

import java.util.Calendar;

public class EventDetailsActivity extends AppCompatActivity {

    // Variables for the event data
    private int eventId;
    private String name, desc, date, time;

    // UI elements on screen
    private TextView tvName, tvDesc, tvDate, tvTime;

    private EventTrackerDB db; // database helper

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_details);

        // Setup toolbar with back button and title
        MaterialToolbar toolbar = findViewById(R.id.topAppBar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true); // show back arrow
            getSupportActionBar().setTitle(R.string.event_details); // set title
        }
        // Handle back arrow press
        toolbar.setNavigationOnClickListener(v ->
                getOnBackPressedDispatcher().onBackPressed()
        );

        // Initialize database
        db = new EventTrackerDB(this);

        // Get event info passed from EventAdapter
        eventId = getIntent().getIntExtra("id", -1);
        name = getIntent().getStringExtra("name");
        desc = getIntent().getStringExtra("desc");
        date = getIntent().getStringExtra("date");
        time = getIntent().getStringExtra("time");

        // Link UI elements
        tvName = findViewById(R.id.textViewEventName);
        tvDesc = findViewById(R.id.textViewEventDescription);
        tvDate = findViewById(R.id.textViewEventDate);
        tvTime = findViewById(R.id.textViewEventTime);
        Button btnEdit = findViewById(R.id.buttonEditEvent);
        Button btnDelete = findViewById(R.id.buttonDeleteEvent);

        // Show the current event data
        bindData();

        // When user clicks Edit, show dialog
        btnEdit.setOnClickListener(v -> showEditDialog());

        // When user clicks Delete, remove event from DB and close
        btnDelete.setOnClickListener(v -> {
            if (eventId >= 0) {
                db.deleteEvent(eventId);
                Toast.makeText(this, "Event deleted", Toast.LENGTH_SHORT).show();
                finish(); // go back to MainActivity
            }
        });
    }

    // Show event info on the screen
    private void bindData() {
        tvName.setText(name);
        tvDesc.setText(desc == null ? "" : desc);
        tvDate.setText("Date: " + (date == null ? "" : date));
        tvTime.setText("Time: " + (time == null ? "" : time));
    }

    // Popup dialog to edit an event
    private void showEditDialog() {
        // Local copies to update inside dialog
        final String[] newName = { name };
        final String[] newDesc = { desc == null ? "" : desc };
        final String[] newDate = { date == null ? "" : date };
        final String[] newTime = { time == null ? "" : time };

        // Create a simple layout for the dialog
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        container.setPadding(pad, pad, pad, pad);

        // Input for event name
        EditText etName = new EditText(this);
        etName.setHint("Event name");
        etName.setText(newName[0]);
        container.addView(etName);

        // Input for description
        EditText etDesc = new EditText(this);
        etDesc.setHint("Description");
        etDesc.setText(newDesc[0]);
        container.addView(etDesc);

        // Button to pick date
        Button btnPickDate = new Button(this);
        btnPickDate.setText("Pick Date (" + (newDate[0].isEmpty() ? "not set" : newDate[0]) + ")");
        container.addView(btnPickDate);

        // Button to pick time
        Button btnPickTime = new Button(this);
        btnPickTime.setText("Pick Time (" + (newTime[0].isEmpty() ? "not set" : newTime[0]) + ")");
        container.addView(btnPickTime);

        // Open date picker when clicked
        btnPickDate.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            new DatePickerDialog(this,
                    (view, y, m, d) -> {
                        newDate[0] = String.format("%02d/%02d/%04d", m + 1, d, y);
                        btnPickDate.setText("Pick Date (" + newDate[0] + ")");
                    },
                    c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)
            ).show();
        });

        // Open time picker when clicked
        btnPickTime.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            new TimePickerDialog(this,
                    (view, hourOfDay, minute) -> {
                        String amPm = (hourOfDay >= 12) ? "PM" : "AM";
                        int hour = hourOfDay % 12;
                        if (hour == 0) hour = 12;
                        newTime[0] = String.format("%02d:%02d %s", hour, minute, amPm);
                        btnPickTime.setText("Pick Time (" + newTime[0] + ")");
                    },
                    c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false
            ).show();
        });

        // Build dialog with Save and Cancel
        new AlertDialog.Builder(this)
                .setTitle("Edit Event")
                .setView(container)
                .setPositiveButton("Save", (d, which) -> {
                    // Save new values
                    newName[0] = etName.getText().toString().trim();
                    newDesc[0] = etDesc.getText().toString().trim();

                    if (newName[0].isEmpty() || newDate[0].isEmpty() || newTime[0].isEmpty()) {
                        Toast.makeText(this, "Name, date, and time are required", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    // Update in DB
                    db.updateEvent(eventId, newName[0], newDesc[0], newDate[0], newTime[0]);

                    // Update local and refresh UI
                    name = newName[0]; desc = newDesc[0]; date = newDate[0]; time = newTime[0];
                    bindData();
                    Toast.makeText(this, "Event updated", Toast.LENGTH_SHORT).show();
                    finish(); // return to MainActivity
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
