package com.example.a360projectpaulinaweaver;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class EventTrackerDB extends SQLiteOpenHelper {

    // Database info
    private static final String DATABASE_NAME = "eventTracker.db"; // file name
    private static final int DATABASE_VERSION = 1; // version number

    // Table and column names for users
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    // Table and column names for events
    public static final String TABLE_EVENTS = "events";
    public static final String COL_EVENT_ID = "id";
    public static final String COL_EVENT_NAME = "name";
    public static final String COL_EVENT_DESC = "description";
    public static final String COL_EVENT_DATE = "date";
    public static final String COL_EVENT_TIME = "time";

    // Constructor
    public EventTrackerDB(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Called when database is created for the first time
    @Override public void onCreate(SQLiteDatabase db) {
        // Create USERS table
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT UNIQUE, " +
                COL_PASSWORD + " TEXT)");

        // Create events table
        db.execSQL("CREATE TABLE " + TABLE_EVENTS + " (" +
                COL_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_EVENT_NAME + " TEXT, " +
                COL_EVENT_DESC + " TEXT, " +
                COL_EVENT_DATE + " TEXT, " +
                COL_EVENT_TIME + " TEXT)");
    }

    // Called when database version changes
    @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        onCreate(db);
    }

    // ---------- USER METHODS ----------

    // Add a new user, returns true if success
    public boolean addUser(String username, String password) {
        // Don’t allow empty username or password
        if (username == null || username.isEmpty()) return false;
        if (password == null || password.isEmpty()) return false;

        SQLiteDatabase db = getWritableDatabase(); // open db to write
        ContentValues cv = new ContentValues();
        cv.put(COL_USERNAME, username);
        cv.put(COL_PASSWORD, password);

        long res = db.insert(TABLE_USERS, null, cv); // insert user
        db.close();
        return res != -1; // -1 if failure
    }

    // Check if username and password exists in DB
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase(); // open db to read
        Cursor c = db.query(TABLE_USERS,
                new String[]{COL_USER_ID}, // just need the ID
                COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password}, null, null, null);

        boolean ok = c.moveToFirst(); // true if a row exists
        c.close();
        db.close();
        return ok;
    }

    // ---------- EVENT METHODS ----------

    // Add a new event, returns row ID or -1 if failed
    public long addEvent(String name, String desc, String date, String time) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_EVENT_NAME, name);
        cv.put(COL_EVENT_DESC, desc);
        cv.put(COL_EVENT_DATE, date);
        cv.put(COL_EVENT_TIME, time);

        long id = db.insert(TABLE_EVENTS, null, cv);
        db.close();
        return id;
    }

    // Update an existing event, returns number of rows updated
    public int updateEvent(int id, String name, String desc, String date, String time) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_EVENT_NAME, name);
        cv.put(COL_EVENT_DESC, desc);
        cv.put(COL_EVENT_DATE, date);
        cv.put(COL_EVENT_TIME, time);

        int rows = db.update(TABLE_EVENTS, cv, COL_EVENT_ID + "=?",
                new String[]{String.valueOf(id)});
        db.close();
        return rows;
    }

    // Delete event by ID, returns number of rows deleted
    public int deleteEvent(int id) {
        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete(TABLE_EVENTS, COL_EVENT_ID + "=?",
                new String[]{String.valueOf(id)});
        db.close();
        return rows;
    }

    // Get all events sorted by date and time
    public Cursor getAllEvents() {
        return getReadableDatabase().query(
                TABLE_EVENTS, null, null, null, null, null,
                COL_EVENT_DATE + " ASC, " + COL_EVENT_TIME + " ASC"
        );
    }
}
